package com.cs472.wapproject.databaseStuffs;

import com.cs472.wapproject.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// This class can be used to initialize the database connection
public class DatabaseConnection {
    public static Connection initializeDatabase()
            throws SQLException, ClassNotFoundException {

        String dbDriver = "com.mysql.cj.jdbc.Driver";
        String dbURL = "jdbc:mysql:// localhost:3306/demoprj?&serverTimezone=America/Chicago";

        String dbUsername = "root1";
        String dbPassword = "root1";

        Class.forName(dbDriver);
        Connection con = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
        return con;
    }


    public static boolean verifyUser(Connection dbc, String uname, String psw) {
            String sql = "select * from users where name=" + "'" + uname + "' and password='" + psw + "'";
            return runQuery(dbc,sql);

    }

    public static boolean isAlreadyExists(Connection dbc, String uname) {

        String sql = "select * from users where name=" + "'" + uname + "'";
       return runQuery(dbc,sql);
    }
    public static ResultSet getAll(Connection dbc){
        ResultSet rs = null;
        String sql="select * from products where 1";
        PreparedStatement pst;
        try {

            pst = dbc.prepareStatement(sql);
            rs = pst.executeQuery();


        } catch (Exception e) {
            e.printStackTrace();

        }
        return rs;
    }

    private static boolean runQuery(Connection dbc, String sql){
        ResultSet rs = null;

        PreparedStatement pst;
        try {

            pst = dbc.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()==true) return true;

        } catch (Exception e) {
            e.printStackTrace();

        }
        return false;

    }
    public static List<Product> getAllProducts() {
        List<Product> list=new ArrayList<>();
        try {
            Connection con = DatabaseConnection.initializeDatabase();
            ResultSet rs = DatabaseConnection.getAll(con);
            while (rs.next()) {
                list.add(new Product(rs.getString("name"),
                        rs.getInt("id"),
                        rs.getString("description"),
                        rs.getString("icon"),
                        rs.getInt("price"),
                        rs.getInt("stock")

                ));
            }


            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


        return list;
    }


}





