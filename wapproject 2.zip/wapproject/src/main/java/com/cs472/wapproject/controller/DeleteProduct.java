package com.cs472.wapproject.controller;

import com.cs472.wapproject.databaseStuffs.DatabaseConnection;
import com.cs472.wapproject.databaseStuffs.PasswordEncryptor;
import com.cs472.wapproject.model.Product;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@WebServlet("/deleteProduct")
public class DeleteProduct extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int pId=Integer.parseInt(request.getParameter("productId"));




        try {
            Connection con = DatabaseConnection.initializeDatabase();


                PreparedStatement st = con.prepareStatement("delete from products where id="+pId);
                st.executeUpdate();


                st.close();
                con.close();
                request.getSession().setAttribute("listofproducts",DatabaseConnection.getAllProducts());

        } catch (Exception e) {

            e.printStackTrace();
        }




        response.sendRedirect("admin.jsp");

    }
}
