package com.cs472.wapproject.controller;



        import com.cs472.wapproject.model.Product;
        import com.google.gson.Gson;

        import java.io.*;
        import java.util.ArrayList;
        import java.util.List;

        import javax.servlet.*;
        import javax.servlet.annotation.WebServlet;
        import javax.servlet.http.*;


/**
 *
 * @author levi
 */
@WebServlet(name = "/cartService", urlPatterns = {"*.ajax"})

public class CartController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.jsp");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        HttpSession sess = request.getSession();
        List<Product> productListInCart = (List<Product>) sess.getAttribute("productsInCart");
        if (productListInCart == null) {
            productListInCart = new ArrayList<Product>();
            sess = request.getSession();
            sess.setAttribute("productsInCart", productListInCart);
        }

        String name = request.getParameter("name");
        int price = Integer.parseInt(request.getParameter("price"));
        String icon =request.getParameter("icon");
        productListInCart.add(new Product(name,price,icon));

        sess.setAttribute("totalPrice",totalPrice(productListInCart));



        String returnDataJson;

        Gson mapper=new Gson();
        returnDataJson = mapper.toJson(productListInCart);





        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        out.write(returnDataJson);
    }


    private int totalPrice(List<Product> products){
            return products.stream().mapToInt(x->x.getPrice()).sum();
    }



}
