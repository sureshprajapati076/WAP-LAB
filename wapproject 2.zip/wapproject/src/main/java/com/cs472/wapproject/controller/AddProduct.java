package com.cs472.wapproject.controller;
import com.cs472.wapproject.databaseStuffs.DatabaseConnection;
import com.cs472.wapproject.databaseStuffs.PasswordEncryptor;
import com.cs472.wapproject.model.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@WebServlet("/addProduct")
public class AddProduct extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String name=request.getParameter("name");
        String desc=request.getParameter("desc");
        int price=Integer.parseInt(request.getParameter("price"));
        int stock=Integer.parseInt(request.getParameter("stock"));



        try {
            Connection con = DatabaseConnection.initializeDatabase();

            PreparedStatement st = con.prepareStatement("insert into products(name,description,price,stock,icon) values(?, ?, ?, ?, ?)");
            st.setString(1, name);
            st.setString(2,desc);
            st.setInt(3,price);
            st.setInt(4,stock);
            st.setString(5,"default.png");

            st.executeUpdate();
            st.close();
            request.getSession().setAttribute("listofproducts",DatabaseConnection.getAllProducts());

        } catch (Exception e) {

            e.printStackTrace();
        }




        response.sendRedirect("admin.jsp");

    }
}
