package quizmodel;

import java.util.ArrayList;

public class Quiz {
    public int correctAns;
    public int questionCounter;
    public ArrayList<String> questions;
    public ArrayList<String> answer;

    public Quiz(){
        this.questionCounter=0;
        this.correctAns=0;
        this.questions=new ArrayList<>();
        this.answer=new ArrayList<>();

        this.questions.add("[ 1, 2, 3, ? ]");
        this.answer.add("4");

        this.questions.add("[ 2, 3, ?, 7, 11, 13 ]");
        this.answer.add("5");

        this.questions.add("[ 0, 2, 4, ? ]");
        this.answer.add("6");

        this.questions.add("[ 15, 13, 11, 9, ? ]");
        this.answer.add("7");

        this.questions.add("[ 3, 6, ? ]");
        this.answer.add("9");





    }
    public int getNumQuestions(){
        return questions.size();
    }
    public boolean isCorrect(String arg) {
        return answer.get(0)==arg;
    }


    public int getNumCorrect(){
        return correctAns;
    }
    public void inc(){
        this.correctAns++;
    }

}
